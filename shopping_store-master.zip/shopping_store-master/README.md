## 项目结构
    1. admin 管理后台
    2. cashier 结算端
    3. db_handler 数据库交互模块
    4. settings 配置文件
    5. requirements.txt 项目需要的python包
## 管理后台启动
    admin下直接运行 views.py
